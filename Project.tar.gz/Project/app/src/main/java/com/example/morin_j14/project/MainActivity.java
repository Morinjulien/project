package com.example.morin_j14.project;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import static com.example.morin_j14.project.FFT.fft;
import static com.example.morin_j14.project.FFT.show;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public static void main(String[] args) {
        Complex[] x = new Complex[0];
        x[0] = new Complex(0, 0);
        x[0] = new Complex(-2*Math.random() + 1, 0);
        show(x, "c = cconvolve(x, x)");
    }

}
